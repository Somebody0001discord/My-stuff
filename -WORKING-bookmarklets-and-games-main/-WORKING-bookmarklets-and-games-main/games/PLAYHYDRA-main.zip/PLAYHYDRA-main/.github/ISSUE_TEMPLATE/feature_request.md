---
name: Feature request
about: Suggest a game or idea for this project
title: ''
labels: game request
assignees: ''

---

**Your suggestion**
[e.g., "Please add Minecraft"]

**Additional context**
[e.g., links to the game/other important or useful information]

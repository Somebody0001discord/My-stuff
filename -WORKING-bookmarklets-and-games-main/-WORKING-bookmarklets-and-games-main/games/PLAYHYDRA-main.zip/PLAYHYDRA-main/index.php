<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="description" content="Unblocked games for the students of MMS" />
    <meta name="keywords" content="playhydra, unblocked games, unblocked, unblocked playhydra" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>HOME | PLAYHYDRA</title>
    <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
</head>

<body>
    <p style="
        padding: 20px;
        background-color: #b03232;
        width: auto;
        text-align: center;
      ">
        <a href="/posts/2022/ukraine.html" style="color: #161515;">An important PSA</a>
    </p>
    <div class="nav-container">
        <a href="index.html"><img src="assets/images/playhydra.png" alt="PLAYHYDRA LOGO" title="PLAYHYDRA"
                class="logo" /></a>

        <nav>
            <a href="index.html" class="nav-item">HOME</a>
            <a href="about.html" class="nav-item">ABOUT</a>
            <a href="/location.html" class="nav-item">LOCATION</a>
        </nav>
    </div>
    <input type="text" id="searchbar" onkeyup="search()" placeholder="Search..." title="Search for games" />
    <div id="search-items">
        <div class="search-item">
            <img src="assets/images/slope.jpg" alt="Slope" class="search-img" />
            <a href="games/slope/index.html">Slope</a>
        </div>
        <div class="search-item">
            <img src="assets/images/retrobowl.jfif" alt="Retrobowl" class="search-img" />
            <a href="games/retrobowl/index.html">Retrobowl</a>
        </div>
        <div class="search-item">
            <img src="assets/images/1v1lol.jpg" alt="1v1.lol" class="search-img" />
            <a href="games/1v1lol/index.html">1v1.lol</a>
        </div>
        <div class="search-item">
            <img src="assets/images/fnaf.jpg" alt="Five Nights at Freddy's" class="search-img" />
            <a href="games/fnaf/index.html">Five Nights at Freddy's</a>
        </div>
        <div class="search-item">
            <img src="assets/images/fnaf 2.jpg" alt="Five Nights at Freddy's 2" class="search-img" />
            <a href="games/fnaf-2/index.html">Five Nights at Freddy's 2</a>
        </div>
        <div class="search-item">
            <img src="assets/images/fnaf 3.jpg" alt="Five Nights at Freddy's 3" class="search-img" />
            <a href="game.html?title=Five Nights at Freddy's 3&url=https://scratch.mit.edu/projects/393471387/embed&height=600&width=1400">Five Nights at Freddy's 3</a>
        </div>
        <div class="search-item">
            <img src="assets/images/2048.png" alt="2048" class="search-img" />
            <a href="games/2048/index.html">2048</a>
        </div>
        <div class="search-item">
            <img src="assets/images/tunnel rush.jpg" alt="Tunnel Rush" class="search-img" />
            <a href="games/tunnel-rush/index.html">Tunnel Rush</a>
        </div>
        <div class="search-item">
            <img src="assets/images/worlds hardest game.jpg" alt="World's Hardest Game" class="search-img" />
            <a href="games/worlds-hardest-game/index.html">World's Hardest Game</a>
        </div>
        <div class="search-item">
            <img src="assets/images/drift hunters.jpg" alt="Drift Hunters" class="search-img" />
            <a href="games/drift-hunters/index.html">Drift Hunters</a>
        </div>
        <div class="search-item">
            <img src="assets/images/cookie clicker.jpg" alt="Cookie Clicker" class="search-img" />
            <a href="games/cookie-clicker/index.html">Cookie Clicker</a>
        </div>
        <div class="search-item">
            <img src="assets/images/run 3.jpg" alt="Run 3" class="search-img" />
            <a href="games/run-3/index.html">Run 3</a>
        </div>
        <div class="search-item">
            <img src="assets/images/fireboy watergirl.jpg" alt="Fireboy and Watergirl" class="search-img" />
            <a href="games/fireboy-watergirl/index.html">Fireboy and Watergirl</a>
        </div>
        <div class="search-item">
            <img src="assets/images/friday night funkin.jpg" alt="Friday Night Funkin'" class="search-img" />
            <a href="games/friday-night-funkin/index.html">Friday Night Funkin'</a>
        </div>
        <div class="search-item">
            <img src="assets/images/madalin stunt cars.jpg" alt="Madalin Stunt Cars 2" class="search-img" />
            <a href="games/madalin-stunt-cars/index.html">Madalin Stunt Cars 2</a>
        </div>
        <!-- this game is broken and there's currently not a good way to fix it, but it's not worth removing yet -->
        <!-- <div class="search-item">
        <img
          src="assets/images/madalin stunt cars multiplayer.jpg"
          alt="Madalin Stunt Cars Multiplayer"
          class="search-img"
        />
        <a href="games/madalin-stunt-cars-multiplayer/index.html"
          >Madalin Stunt Cars Multiplayer</a
        >
      </div> -->
        <div class="search-item">
            <img src="assets/images/tetris.jpg" alt="Tetris" class="search-img" />
            <a href="games/tetris/index.html">Tetris</a>
        </div>
        <div class="search-item">
            <img src="assets/images/modern blocky paint.jpg" alt="Modern Blocky Paint" class="search-img" />
            <a href="games/modern-blocky-paint/index.html">Modern Blocky Paint</a>
        </div>
        <div class="search-item">
            <img src="assets/images/idle breakout.jpg" alt="Idle Breakout" class="search-img" />
            <a href="games/idle-breakout/index.html">Idle Breakout</a>
        </div>
        <div class="search-item">
            <img src="assets/images/dino game.jpg" alt="Chrome Dino Game" class="search-img" />
            <a href="games/dino-game/index.html">Chrome Dino Game</a>
        </div>
        <div class="search-item">
            <img src="assets/images/tanuki sunset.jpg" alt="Tanuki Sunset" class="search-img" />
            <a
                href="game.html?title=Tanuki Sunset&url=https://tanuki-sunset.vakhtangi1980.repl.co/&width=1400&height=680">Tanuki
                Sunset</a>
        </div>
        <div class="search-item">
            <img src="assets/images/bloons td 4.jpg" alt="Bloons Tower Defense 4" class="search-img" />
            <a
                href="/game.html?title=Bloons Tower Defense 4&width=600&height=600&url=https://scratch.mit.edu/projects/62965100/embed">Bloons
                Tower Defense 4</a>
        </div>
    </div>
    <!-- hey there, code digger -->
    <!-- https://lps7x.csb.app/assets/css/thing.txt -->
    <sub><em>BROUGHT TO YOU BY THE STUDENTS OF MMS</em></sub>
    <script>
        function search() {
            let input = document.getElementById("searchbar");
            let filter = input.value.toLowerCase();
            let container = document.getElementById("search-items");
            let items = container.getElementsByClassName("search-item");

            for (var i = 0; i < items.length; i++) {
                let div = items[i];
                let element = div.getElementsByTagName("a")[0];
                if (!element.innerHTML.toLowerCase().includes(filter)) {
                    items[i].style.display = "none";
                } else {
                    items[i].style.display = "";
                }
            }
        }
    </script>
</body>

</html>

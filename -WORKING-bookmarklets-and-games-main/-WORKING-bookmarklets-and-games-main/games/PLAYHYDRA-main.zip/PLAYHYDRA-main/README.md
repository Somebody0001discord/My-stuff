# 8/23/22: [PLAYHYDRA has been archived](https://wqqcwh.csb.app/index.html)
# PLAYHYDRA
*Blocked and unblocked **1** time so far*!

[![Deploy to Heroku](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/official/heroku.svg)](https://heroku.com/deploy/?template=https://github.com/liamhtml/playhydra) [![Run on Replit](https://raw.githubusercontent.com/BinBashBanana/deploy-buttons/master/buttons/official/replit.svg)](https://replit.com/github/liamhtml/playhydra)

# overview
- just a basic games site for mms students
- [proof this is the real deal and not a cheap clone](https://lps7x.csb.app/assets/css/proof.txt)
- popular for some reason
- ***star before forking pls or i will steal your mac + chese***
## adding games
send us an [email](mailto:playhydrarequests@gmail.com), [create an issue with your request](https://github.com/liamhtml/PLAYHYDRA/issues/new?assignees=&labels=game+request&template=feature_request.md&title=), or, if you know how to code, [check out this guide for contributors.](https://github.com/liamhtml/PLAYHYDRA/blob/main/.github/CONTRIBUTING.md)
## to-add list
ngl these will probably never happen because i have lost all motivation to work on playhydra
- learn to fly 1, 2, 3
- fnaf 4
- totally accurate battle simulator (probably not possible)
- justfall.lol
- slope 2?? (don't think this exists)
- csgo case clicker
- basketball stars
- snake
- minecraft (probably a terrible ripoff version)
- space invaders
- minesweeper
- candy jump
